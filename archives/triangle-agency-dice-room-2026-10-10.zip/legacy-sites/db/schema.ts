import { sql } from "drizzle-orm";
import { integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const rooms = sqliteTable("rooms", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  createdBy: text("created_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const roomMembers = sqliteTable(
  "room_members",
  {
    id: text("id").primaryKey(),
    roomId: text("room_id").notNull(),
    userId: text("user_id").notNull(),
    displayName: text("display_name").notNull(),
    lastSeenAt: text("last_seen_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("room_members_room_user_idx").on(table.roomId, table.userId),
  ],
);

export const publicRolls = sqliteTable("public_rolls", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull(),
  userId: text("user_id").notNull(),
  displayName: text("display_name").notNull(),
  diceJson: text("dice_json").notNull(),
  threeCount: integer("three_count").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const privateRolls = sqliteTable("private_rolls", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull(),
  ownerUserId: text("owner_user_id").notNull(),
  publicRollId: text("public_roll_id"),
  result: integer("result").notNull(),
  diceExpression: text("dice_expression").notNull().default("1D8"),
  resultsJson: text("results_json").notNull().default("[]"),
  label: text("label").notNull().default("修正"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
