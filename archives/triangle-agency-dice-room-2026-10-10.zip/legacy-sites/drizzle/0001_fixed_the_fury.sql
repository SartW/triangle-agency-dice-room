ALTER TABLE `private_rolls` ADD `dice_expression` text DEFAULT '1D8' NOT NULL;--> statement-breakpoint
ALTER TABLE `private_rolls` ADD `results_json` text DEFAULT '[]' NOT NULL;--> statement-breakpoint
ALTER TABLE `private_rolls` ADD `label` text DEFAULT '修正' NOT NULL;