import { requireChatGPTUser } from "./chatgpt-auth";
import DiceRoom from "./dice-room";

export default async function Home() {
  const user = await requireChatGPTUser("/");
  return <DiceRoom accountName={user.displayName} />;
}
