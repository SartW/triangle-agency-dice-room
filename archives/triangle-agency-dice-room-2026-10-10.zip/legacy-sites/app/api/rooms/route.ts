import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { roomMembers, rooms } from "../../../db/schema";
import { getChatGPTUser } from "../../chatgpt-auth";

function cleanName(value: unknown, fallback: string) {
  const name = typeof value === "string" ? value.trim().slice(0, 24) : "";
  return name || fallback.slice(0, 24) || "未命名特工";
}

function randomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (value) => alphabet[value % alphabet.length]).join("");
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请先登录" }, { status: 401 });

  const body = (await request.json()) as {
    action?: string;
    code?: string;
    displayName?: string;
  };
  const db = getDb();
  const displayName = cleanName(body.displayName, user.displayName);

  if (body.action === "create") {
    let code = randomCode();
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const existing = await db.select({ id: rooms.id }).from(rooms).where(eq(rooms.code, code)).limit(1);
      if (!existing.length) break;
      code = randomCode();
    }
    const roomId = crypto.randomUUID();
    await db.insert(rooms).values({
      id: roomId,
      code,
      name: "分部外勤骰房",
      createdBy: user.userId,
    });
    await db.insert(roomMembers).values({
      id: crypto.randomUUID(),
      roomId,
      userId: user.userId,
      displayName,
      lastSeenAt: new Date().toISOString(),
    });
    return Response.json({ room: { code, name: "分部外勤骰房" } }, { status: 201 });
  }

  const code = (body.code ?? "").trim().toUpperCase();
  if (!/^[A-Z2-9]{6}$/.test(code)) {
    return Response.json({ error: "请输入 6 位房间代号" }, { status: 400 });
  }
  const [room] = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!room) return Response.json({ error: "未找到该骰房" }, { status: 404 });

  const [member] = await db
    .select()
    .from(roomMembers)
    .where(and(eq(roomMembers.roomId, room.id), eq(roomMembers.userId, user.userId)))
    .limit(1);
  const now = new Date().toISOString();
  if (member) {
    await db.update(roomMembers).set({ displayName, lastSeenAt: now }).where(eq(roomMembers.id, member.id));
  } else {
    await db.insert(roomMembers).values({
      id: crypto.randomUUID(),
      roomId: room.id,
      userId: user.userId,
      displayName,
      lastSeenAt: now,
    });
  }
  return Response.json({ room: { code: room.code, name: room.name } });
}
