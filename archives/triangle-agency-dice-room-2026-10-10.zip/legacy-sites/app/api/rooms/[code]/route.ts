import { and, desc, eq, gte } from "drizzle-orm";
import { getDb } from "../../../../db";
import { privateRolls, publicRolls, roomMembers, rooms } from "../../../../db/schema";
import { getChatGPTUser } from "../../../chatgpt-auth";

export async function GET(_request: Request, context: { params: Promise<{ code: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请先登录" }, { status: 401 });
  const { code: rawCode } = await context.params;
  const code = rawCode.toUpperCase();
  const db = getDb();
  const [room] = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!room) return Response.json({ error: "骰房不存在" }, { status: 404 });

  const [member] = await db
    .select()
    .from(roomMembers)
    .where(and(eq(roomMembers.roomId, room.id), eq(roomMembers.userId, user.userId)))
    .limit(1);
  if (!member) return Response.json({ error: "请先加入骰房" }, { status: 403 });

  await db.update(roomMembers).set({ lastSeenAt: new Date().toISOString() }).where(eq(roomMembers.id, member.id));
  const activeSince = new Date(Date.now() - 2 * 60 * 1000).toISOString();
  const [rollRows, privateRows, members] = await Promise.all([
    db.select().from(publicRolls).where(eq(publicRolls.roomId, room.id)).orderBy(desc(publicRolls.createdAt)).limit(40),
    db.select().from(privateRolls).where(and(eq(privateRolls.roomId, room.id), eq(privateRolls.ownerUserId, user.userId))).orderBy(desc(privateRolls.createdAt)).limit(40),
    db.select({ displayName: roomMembers.displayName }).from(roomMembers).where(and(eq(roomMembers.roomId, room.id), gte(roomMembers.lastSeenAt, activeSince))),
  ]);

  return Response.json({
    room: { code: room.code, name: room.name },
    rolls: rollRows.map((roll) => ({ id: roll.id, displayName: roll.displayName, threeCount: roll.threeCount, createdAt: roll.createdAt, dice: JSON.parse(roll.diceJson) as number[] })),
    privateRolls: privateRows.map((roll) => ({ id: roll.id, publicRollId: roll.publicRollId, result: roll.result, diceExpression: roll.diceExpression, results: JSON.parse(roll.resultsJson) as number[], label: roll.label, createdAt: roll.createdAt })),
    members,
  });
}
