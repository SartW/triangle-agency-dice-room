import { and, eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { privateRolls, publicRolls, roomMembers, rooms } from "../../../../../db/schema";
import { getChatGPTUser } from "../../../../chatgpt-auth";

function die(sides: number) {
  const value = new Uint32Array(1);
  crypto.getRandomValues(value);
  return (value[0] % sides) + 1;
}

function readSecretDice(value: unknown) {
  const raw = (value && typeof value === "object" ? value : {}) as { count?: unknown; sides?: unknown; label?: unknown };
  const count = Math.max(1, Math.min(6, Math.floor(Number(raw.count) || 1)));
  const sides = Math.max(2, Math.min(100, Math.floor(Number(raw.sides) || 8)));
  const label = (typeof raw.label === "string" ? raw.label.trim() : "").slice(0, 16) || "修正";
  const results = Array.from({ length: count }, () => die(sides));
  return { count, sides, label, results, total: results.reduce((sum, result) => sum + result, 0), expression: `${count}D${sides}` };
}

export async function POST(request: Request, context: { params: Promise<{ code: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请先登录" }, { status: 401 });
  const { code: rawCode } = await context.params;
  const db = getDb();
  const [room] = await db.select().from(rooms).where(eq(rooms.code, rawCode.toUpperCase())).limit(1);
  if (!room) return Response.json({ error: "骰房不存在" }, { status: 404 });
  const [member] = await db
    .select()
    .from(roomMembers)
    .where(and(eq(roomMembers.roomId, room.id), eq(roomMembers.userId, user.userId)))
    .limit(1);
  if (!member) return Response.json({ error: "请先加入骰房" }, { status: 403 });

  const body = (await request.json()) as { mode?: "public" | "secret"; includeCorrection?: boolean; secretDice?: unknown };
  const now = new Date().toISOString();
  if (body.mode === "secret") {
    const chosen = readSecretDice(body.secretDice);
    const secret = {
      id: crypto.randomUUID(), roomId: room.id, ownerUserId: user.userId,
      publicRollId: null, result: chosen.total, diceExpression: chosen.expression,
      resultsJson: JSON.stringify(chosen.results), label: chosen.label, createdAt: now,
    };
    await db.insert(privateRolls).values(secret);
    return Response.json({ privateRoll: { ...secret, results: chosen.results } }, { status: 201 });
  }

  const dice = Array.from({ length: 6 }, () => die(4));
  const roll = {
    id: crypto.randomUUID(), roomId: room.id, userId: user.userId,
    displayName: member.displayName, diceJson: JSON.stringify(dice),
    threeCount: dice.filter((value) => value === 3).length, createdAt: now,
  };
  await db.insert(publicRolls).values(roll);
  let correction: typeof privateRolls.$inferInsert | null = null;
  if (body.includeCorrection) {
    const chosen = readSecretDice(body.secretDice);
    correction = {
      id: crypto.randomUUID(), roomId: room.id, ownerUserId: user.userId,
      publicRollId: roll.id, result: chosen.total, diceExpression: chosen.expression,
      resultsJson: JSON.stringify(chosen.results), label: chosen.label, createdAt: now,
    };
    await db.insert(privateRolls).values(correction);
  }
  return Response.json({ roll: { ...roll, dice }, privateRoll: correction }, { status: 201 });
}
