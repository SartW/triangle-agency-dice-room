import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "三角机构 · 分部公共骰房",
  description: "分部外勤专用的 6D4 公共检定与私人暗骰终端。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
